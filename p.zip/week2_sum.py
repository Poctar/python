for i in range(3):
    print("meow")


while True:
    n = int(input("What's n? "))
    if n < 0:
        continue
    else:
        break

# next line
len()
list
dict
